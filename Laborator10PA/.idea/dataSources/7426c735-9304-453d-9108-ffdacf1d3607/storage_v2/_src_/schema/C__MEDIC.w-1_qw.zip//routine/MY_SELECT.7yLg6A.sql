create PROCEDURE my_select(selectArg VARCHAR2) AS
  v_cursor_id NUMBER;
  v_ok        NUMBER;
  v_rec_tab     DBMS_SQL.DESC_TAB;
  v_nr_col     NUMBER;
  v_total_coloane     NUMBER; 

  v_varchar2 VARCHAR2(4000);
  v_number NUMBER;
  v_date DATE;
BEGIN
  v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_cursor_id , selectArg, DBMS_SQL.NATIVE);

  DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);

  FOR i IN 1..v_total_coloane LOOP
    CASE (v_rec_tab(i).col_type)
        WHEN 1 THEN DBMS_SQL.DEFINE_COLUMN(v_cursor_id, i, v_varchar2, 4000);
        WHEN 2 THEN DBMS_SQL.DEFINE_COLUMN(v_cursor_id, i, v_number);
        WHEN 12 THEN DBMS_SQL.DEFINE_COLUMN(v_cursor_id, i, v_date);
    END CASE; 
  END LOOP;

  v_ok := DBMS_SQL.EXECUTE(v_cursor_id );

  WHILE (dbms_sql.fetch_rows(v_cursor_id) > 0) LOOP
    for i in 1 .. v_total_coloane loop
        CASE (v_rec_tab(i).col_type)
            WHEN 1 THEN DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, v_varchar2); DBMS_OUTPUT.PUT_LINE(v_rec_tab(i).col_name || ': ' || v_varchar2);
            WHEN 2 THEN DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, v_number); DBMS_OUTPUT.PUT_LINE(v_rec_tab(i).col_name || ': ' || v_number);
            WHEN 12 THEN DBMS_SQL.COLUMN_VALUE(v_cursor_id, i, v_date); DBMS_OUTPUT.PUT_LINE(v_rec_tab(i).col_name || ': ' || v_date);
        END CASE; 
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('');
  END LOOP;

  DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
END;
/

