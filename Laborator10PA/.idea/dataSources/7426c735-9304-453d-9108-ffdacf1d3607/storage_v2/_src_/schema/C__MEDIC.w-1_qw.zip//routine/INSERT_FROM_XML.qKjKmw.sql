create PROCEDURE insert_from_xml AS
    f_in utl_file.file_type;
    v_data RAW(2000);
    v_data_string VARCHAR2(4000);
    v_object XMLTYPE;
BEGIN
    f_in := utl_file.fopen('MEDICDIR', 'o_persoana.xml', 'r');

    utl_file.get_raw(f_in, v_data);
    v_data_string := utl_raw.cast_to_varchar2(v_data);
    v_object := XMLTYPE(v_data_string);

    INSERT INTO persoana2 VALUES(
        extractValue(v_object, '/person/id'),
        extractValue(v_object, '/person/surname'),
        extractValue(v_object, '/person/name'),
        extractValue(v_object, '/person/gender'),
        TO_DATE(extractValue(v_object, '/person/date_of_birth'), 'YYYY-MM-DD')
    );

    utl_file.fclose(f_in);
END;
/

