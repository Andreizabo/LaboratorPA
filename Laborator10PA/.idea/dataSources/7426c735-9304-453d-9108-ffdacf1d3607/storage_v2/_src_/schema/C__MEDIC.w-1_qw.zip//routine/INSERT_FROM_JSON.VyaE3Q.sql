create PROCEDURE insert_from_json AS
    f_in utl_file.file_type;
    v_data RAW(2000);
    v_data_string VARCHAR2(4000);
BEGIN
    f_in := utl_file.fopen('MEDICDIR', 'o_persoana.json', 'r');

    utl_file.get_raw(f_in, v_data);
    v_data_string := utl_raw.cast_to_varchar2(v_data);

    INSERT INTO persoana2 VALUES(
        json_value(v_data_string, '$.id' RETURNING NUMBER),
        json_value(v_data_string, '$.surname' RETURNING VARCHAR2),
        json_value(v_data_string, '$.name' RETURNING VARCHAR2),
        json_value(v_data_string, '$.gender' RETURNING VARCHAR2),
        TO_DATE(json_value(v_data_string, '$.date_of_birth' RETURNING VARCHAR2), 'YYYY-MM-DD')
    );

    utl_file.fclose(f_in);
END;
/

