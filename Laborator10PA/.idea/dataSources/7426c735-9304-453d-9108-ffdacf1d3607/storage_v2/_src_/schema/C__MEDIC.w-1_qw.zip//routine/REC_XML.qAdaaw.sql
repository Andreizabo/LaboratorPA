create FUNCTION rec_xml(a_id NUMBER, a_exit NUMBER)
RETURN VARCHAR2 AS
BEGIN
    IF a_id >= a_exit - 1 THEN
        RETURN get_xml_id(a_id);
    ELSE
        RETURN get_xml_id(a_id) || chr(10) || rec_xml(a_id + 1, a_exit);
    END IF;
END;
/

