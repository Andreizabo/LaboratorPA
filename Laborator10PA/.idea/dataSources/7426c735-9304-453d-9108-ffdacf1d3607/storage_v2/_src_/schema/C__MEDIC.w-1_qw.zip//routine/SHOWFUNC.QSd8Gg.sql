create PROCEDURE showFunc AS
    funcName VARCHAR2(4000);
    funcDet VARCHAR2(3);
    rowsNum NUMBER;
    CURSOR funcs IS
        SELECT object_name, deterministic FROM USER_PROCEDURES;
BEGIN
    OPEN funcs;
    LOOP
        FETCH funcs INTO funcName, funcDet;
        EXIT WHEN funcs%NOTFOUND;
        SELECT COUNT(*) INTO rowsNum FROM USER_SOURCE WHERE name = funcName;
        IF funcDet = 'NO' THEN
            DBMS_OUTPUT.PUT_LINE('Function ' || funcName || ' has ' || rowsNum || 'rows of code and is not deterministic');
        ELSE
            DBMS_OUTPUT.PUT_LINE('Function ' || funcName || ' has ' || rowsNum || 'rows of code and is deterministic');
        END IF;

    END LOOP;
    CLOSE funcs;
END;
/

