create PROCEDURE export_csv(path VARCHAR2) AS
    f_out utl_file.file_type;
    v_counter INT;
    v_max INT;
    v_persoane_row PERSOANE%ROWTYPE;
BEGIN
    f_out := utl_file.fopen('MEDICDIR', path, 'w');

    SELECT COUNT(*)
    INTO v_max
    FROM PERSOANE;

    FOR v_counter IN 1..v_max
    LOOP
        SELECT * INTO v_persoane_row FROM PERSOANE WHERE id = v_counter;
        utl_file.put_line(f_out, v_persoane_row.nume || ',' || v_persoane_row.prenume || ',' || v_persoane_row.email || ',' || v_persoane_row.telefon);
    END LOOP;
    utl_file.fclose(f_out);
END;
/

