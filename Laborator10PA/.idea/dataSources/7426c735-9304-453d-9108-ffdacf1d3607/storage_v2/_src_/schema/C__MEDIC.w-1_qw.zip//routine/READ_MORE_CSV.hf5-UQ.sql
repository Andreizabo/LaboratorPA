create PROCEDURE read_more_csv(path VARCHAR2) AS
    f_in utl_file.file_type;
    v_read VARCHAR2(4000);
    v_count NUMBER;
    v_surname VARCHAR2(20);
    v_name VARCHAR2(20);
    v_email VARCHAR2(30);
    v_telefon VARCHAR2(10);
    already_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(already_exists, -20001);
BEGIN
    f_in := utl_file.fopen('MEDICDIR', path, 'r');

    LOOP
    BEGIN
        utl_file.get_line(f_in, v_read);

        IF v_read IS NULL THEN
            EXIT;
        END IF;

        SELECT REGEXP_SUBSTR(v_read, '[^,]+', 1, 1)
        INTO v_surname
        FROM DUAL;
        SELECT REGEXP_SUBSTR(v_read, '[^,]+', 1, 2)
        INTO v_name
        FROM DUAL;
        SELECT REGEXP_SUBSTR(v_read, '[^,]+', 1, 3)
        INTO v_email
        FROM DUAL;
        SELECT REGEXP_SUBSTR(v_read, '[^,]+', 1, 4)
        INTO v_telefon
        FROM DUAL;

        SELECT COUNT(*) INTO v_count
        FROM PERSOANE
        WHERE nume = v_surname AND prenume = v_name AND email = v_email AND telefon = v_telefon;

        IF v_count > 0 THEN
            RAISE already_exists;
        ELSE
            INSERT INTO PERSOANE VALUES (
                (select NVL(max(id), 0) + 1 from PERSOANE),
                v_surname,
                v_name,
                v_email,
                v_telefon
            );
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            EXIT;
    END;
    END LOOP;
END;
/

