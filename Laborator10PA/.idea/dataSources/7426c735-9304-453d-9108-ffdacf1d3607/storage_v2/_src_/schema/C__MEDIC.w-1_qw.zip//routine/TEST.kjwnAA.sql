create PROCEDURE test AS
BEGIN
    DBMS_OUTPUT.PUT_LINE('test');
END;
/

