create PROCEDURE getFuncText(funcName VARCHAR2) AS
    funcText VARCHAR2(4000);
    CURSOR code IS
        SELECT text FROM USER_SOURCE WHERE LOWER(TRIM(name)) = funcName;
BEGIN
    OPEN code;
    LOOP
        FETCH code INTO funcText;
        EXIT WHEN code%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(funcText);
    END LOOP;
    CLOSE code;
END;
/

