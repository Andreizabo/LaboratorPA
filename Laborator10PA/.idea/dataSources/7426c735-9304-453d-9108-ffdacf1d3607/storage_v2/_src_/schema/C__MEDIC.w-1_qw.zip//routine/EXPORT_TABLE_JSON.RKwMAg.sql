create PROCEDURE export_table_json IS
    f_out utl_file.file_type;
    v_data VARCHAR2(4000);
    v_row_number NUMBER;
    v_counter NUMBER;
BEGIN
    f_out := utl_file.fopen('MEDICDIR', 'persoana.json', 'w');
    utl_file.put_line(f_out, '[');
    SELECT COUNT(*) INTO v_row_number FROM PERSOANA;
    v_counter := 1;
    LOOP
        IF v_counter > v_row_number THEN
            EXIT;
        END IF;
        SELECT json_query(
            json_object('id'            VALUE id_persoana,
                        'surname'          VALUE nume,
                        'name'       VALUE prenume,
                        'gender'           VALUE sex,
                        'date_of_birth' VALUE TO_CHAR(data_nastere, 'YYYY-MM-DD')
            ), '$' returning varchar2(4000) pretty)
        INTO v_data
        FROM PERSOANA WHERE id_persoana = v_counter; 
        utl_file.put(f_out, v_data);
        IF v_counter = v_row_number THEN
            utl_file.put_line(f_out, '');
        ELSE
            utl_file.put_line(f_out, ',');
        END IF;

        v_counter := v_counter + 1;
    END LOOP;
    utl_file.put_line(f_out, ']');
    utl_file.fclose(f_out);
END;
/

