create PROCEDURE row_as_json(a_id NUMBER) IS
    f_out utl_file.file_type;
    v_data VARCHAR2(4000);
BEGIN
    f_out := utl_file.fopen('MEDICDIR', 'o_persoana.json', 'w');
    SELECT json_query(
    json_object('id'            VALUE id_persoana,
                'surname'          VALUE nume,
                'name'       VALUE prenume,
                'gender'           VALUE sex,
                'date_of_birth' VALUE TO_CHAR(data_nastere, 'YYYY-MM-DD')
    ), '$' returning varchar2(4000) pretty)
    INTO v_data
    FROM PERSOANA WHERE id_persoana = a_id;
    utl_file.put(f_out, v_data);
    utl_file.fclose(f_out);
END;
/

