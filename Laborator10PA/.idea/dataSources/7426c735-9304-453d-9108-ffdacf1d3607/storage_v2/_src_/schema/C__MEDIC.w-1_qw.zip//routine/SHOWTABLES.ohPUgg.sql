create PROCEDURE showTables AS
    tabName VARCHAR2(4000);
    tabRows NUMBER;
    indName VARCHAR2(4000);
    conName VARCHAR2(4000);
    conType VARCHAR2(4000);
    columnName VARCHAR2(4000);
    CURSOR tabs IS
        SELECT table_name, num_rows FROM USER_TABLES;
    CURSOR constr(p_name VARCHAR2) IS
        SELECT constraint_name, constraint_type FROM USER_CONSTRAINTS WHERE table_name = p_name;
    CURSOR indx(p_name VARCHAR2) IS
        SELECT index_name FROM USER_INDEXES WHERE table_name = p_name;
    CURSOR clm(p_name VARCHAR2) IS
        SELECT column_name FROM ALL_CONS_COLUMNS WHERE constraint_name = p_name;
BEGIN
    OPEN tabs;
    LOOP
        FETCH tabs INTO tabName, tabRows;
        EXIT WHEN tabs%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('');
        DBMS_OUTPUT.PUT_LINE(tabName || ' has ' || tabRows || ' entries ');
        DBMS_OUTPUT.PUT_LINE('Constraints: ');
        OPEN constr(tabName);
        LOOP
            FETCH constr INTO conName, conType;
            EXIT WHEN constr%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE(conName || ' has the type ' || conType || ' and affects ');
            OPEN clm(conName);
            LOOP
                FETCH clm INTO columnName;
                EXIT WHEN clm%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE(columnName);
            END LOOP;
            CLOSE clm;
        END LOOP;
        CLOSE constr;
        DBMS_OUTPUT.PUT_LINE('');
        DBMS_OUTPUT.PUT_LINE('Indexes: ');
        OPEN indx(tabName);
        LOOP
            FETCH indx INTO indName;
            EXIT WHEN indx%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE(indName);
        END LOOP;
        CLOSE indx;
    END LOOP;
    CLOSE tabs;
END;
/

