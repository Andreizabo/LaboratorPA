create FUNCTION get_xml_id(a_id NUMBER)
RETURN VARCHAR2 AS
    v_data XMLTYPE;
    v_string VARCHAR2(4000);
BEGIN
    SELECT XMLELEMENT("person", 
                XMLELEMENT("id", id_persoana),
                XMLELEMENT("surname", nume),
                XMLELEMENT("name", prenume),
                XMLELEMENT("gender", sex),
                XMLELEMENT("date_of_birth", data_nastere)
    )
    INTO v_data
    FROM PERSOANA WHERE id_persoana = a_id;
    SELECT XMLSERIALIZE(DOCUMENT XMLTYPE(v_data.getStringVal) AS VARCHAR2(4000) INDENT SIZE = 1) INTO v_string FROM DUAL;
    RETURN v_string;
END;
/

