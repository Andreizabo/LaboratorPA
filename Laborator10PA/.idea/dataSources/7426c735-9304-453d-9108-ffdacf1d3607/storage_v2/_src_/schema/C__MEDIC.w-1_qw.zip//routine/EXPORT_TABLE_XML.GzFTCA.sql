create PROCEDURE export_table_xml IS
    f_out utl_file.file_type;
    v_data VARCHAR2(4000);
    v_counter NUMBER;
    v_len NUMBER;
BEGIN
    f_out := utl_file.fopen('MEDICDIR', 'persoana.xml', 'w');
    SELECT COUNT(*) INTO v_len FROM PERSOANA;
    v_counter := 1;
    LOOP
        IF v_counter > v_len THEN
            EXIT;
        END IF;

        IF v_len - v_counter < 10 THEN
            v_data := rec_xml(v_counter, v_len + 1);
        ELSE
            v_data := rec_xml(v_counter, v_counter + 10);
        END IF;

        utl_file.put(f_out, v_data);
        utl_file.put_line(f_out, '');
        v_counter := v_counter + 10;
    END LOOP;
    utl_file.fclose(f_out);
END;
/

